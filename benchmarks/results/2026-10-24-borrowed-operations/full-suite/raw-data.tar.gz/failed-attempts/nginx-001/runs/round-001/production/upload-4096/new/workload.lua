wrk.method="POST"; wrk.body=string.rep("x", 4096); wrk.headers["Content-Type"]="application/octet-stream"
done = function(summary, latency, requests)
  io.write(string.format('BENCH_JSON {"requests":%d,"duration_us":%d,"bytes":%d,"p50_us":%.3f,"p95_us":%.3f,"p99_us":%.3f,"errors":%d}\n',
    summary.requests, summary.duration, summary.bytes, latency:percentile(50), latency:percentile(95), latency:percentile(99),
    summary.errors.connect + summary.errors.read + summary.errors.write + summary.errors.status + summary.errors.timeout))
end
