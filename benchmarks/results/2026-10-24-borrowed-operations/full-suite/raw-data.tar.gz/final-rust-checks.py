import json
import subprocess
import time
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
output = dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), checks=[])
commands = [['cargo', 'fmt', '--all'],
            ['cargo', 'clippy', '--workspace', '--all-targets', '--all-features'],
            ['cargo', 'test', '--workspace', '--all-targets', '--all-features'],
            ['python3', '-m', 'unittest', 'discover', '-s', 'benchmarks', '-p', 'test_*.py']]
for i, command in enumerate(commands):
    log = p / ('final-check-' + str(i + 1) + '.log')
    check = dict(command=command, log=log.name, started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    output['checks'].append(check)
    with log.open('w') as handle:
        result = subprocess.run(command, cwd=root, stdout=handle, stderr=subprocess.STDOUT)
    check.update(returncode=result.returncode, finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    (p / 'final-checks.json').write_text(json.dumps(output, indent=2) + '\n')
    print(command, result.returncode, flush=True)
    assert result.returncode == 0
subprocess.run(['git', 'diff', '--exit-code', '--', 'src'], cwd=root, check=True, stdout=subprocess.DEVNULL)
output.update(finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), status='complete')
(p / 'final-checks.json').write_text(json.dumps(output, indent=2) + '\n')
