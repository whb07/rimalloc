import json
import math
import statistics
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
plan = json.loads((p / 'measurement-plan.json').read_text())
original_root = Path(plan['artifact_fingerprints']['old.so']['path']).parents[1]
families = ['nginx-header-aa'] if '--header-aa' in sys.argv else (['nginx-holdout'] if '--holdout' in sys.argv else ['webserver', 'nginx'])
output = {family: [] for family in families}
output['incomplete'] = []
for family in families:
    is_nginx = family.startswith('nginx')
    path = p / family / 'runs.json'
    if not path.exists() or json.loads(path.read_text())['status'] != 'complete':
        output['incomplete'].append(family)
        continue
    data = json.loads(path.read_text())
    groups = {}
    pairs = {}
    for run in data['runs']:
        assert run['exit_code'] == 0
        actual = 'old' if family == 'nginx-header-aa' else run['label']
        assert run['library_sha256'] == plan['artifact_fingerprints'][actual + '.so']['sha256']
        pair = pairs.setdefault((json.dumps(run['case'], sort_keys=True), run['round']), {})
        assert run['label'] not in pair
        pair[run['label']] = run
        directory = p / Path(run['directory']).relative_to(original_root)
        result = json.loads((directory / ('nginx.json' if is_nginx else 'webserver.json')).read_text())
        expected_config = {k:v for k,v in run['configuration'].items() if k != 'family'}
        assert result['status'] == 'complete' and result['config'] == expected_config
        case = run['case']
        key = (case.get('profile'), case['case']['label'] if is_nginx else case['scenario'])
        records = result['runs'] if is_nginx else [result['run']]
        metrics = dict(normalized_ns=1e9/statistics.median(r['requests_per_second'] for r in records))
        assert math.isclose(metrics['normalized_ns'], run['measurement']['median'], rel_tol=1e-12)
        for metric in ['p50_us', 'p95_us', 'p99_us', 'cpu_seconds_per_request',
                       'peak_worker_pss_bytes' if is_nginx else 'peak_server_pss_bytes']:
            values = [r.get(metric) for r in records]
            assert all(v is None or v >= 0 for v in values)
            metrics[metric] = None if any(v is None for v in values) else (max(values) if 'pss_bytes' in metric else statistics.median(values))
        metrics['errors'] = sum(r['errors'] for r in records)
        assert metrics['errors'] == 0
        if is_nginx:
            for metric in ['allocations_per_request', 'requested_bytes_per_request']:
                metrics[metric] = result['allocator_traffic'][metric]
            metrics['idle_final_pss_bytes'] = result['idle'][-1][-1]['pss_bytes'] if result['idle'] else None
        metrics['quality_flags'] = result['quality_flags']
        groups[(*key, run['round'], run['label'])] = metrics
    for pair in pairs.values():
        assert set(pair) == {'old', 'new'}
        for field in ['command', 'environment', 'configuration']:
            assert pair['old'][field] == pair['new'][field]
    expected_cases = data.get('cases') if is_nginx else [dict(scenario=s) for s in data['controls']['scenarios']]
    if expected_cases is None:
        expected_cases = [dict(profile=profile, case=case) for profile in data['controls']['profiles'] for case in data['controls']['cases']]
    assert len(data['runs']) == 2 * data['controls']['rounds'] * len(expected_cases)
    assert {identity for identity, i in pairs} == {json.dumps(case, sort_keys=True) for case in expected_cases}
    for profile, case in sorted({(profile, case) for profile, case, i, label in groups}, key=str):
        records = {label: [groups[(profile, case, i, label)] for i in range(data['controls']['rounds'])] for label in ['old', 'new']}
        medians = {}
        ratios = {}
        for metric in records['old'][0]:
            if metric in ['errors', 'quality_flags']:
                continue
            medians[metric] = {label: None if any(r[metric] is None for r in rows) else statistics.median(r[metric] for r in rows) for label, rows in records.items()}
            paired = [b[metric] / a[metric] for a, b in zip(records['old'], records['new']) if a[metric] is not None and b[metric] is not None and a[metric] > 0]
            ratios[metric] = dict(paired=paired, median=statistics.median(paired) if paired else None)
        output[family].append(dict(profile=profile, case=case, medians=medians, ratios=ratios,
                                   quality_flags={label: sorted({flag for r in rows for flag in r['quality_flags']}) for label, rows in records.items()},
                                   errors={label: sum(r['errors'] for r in rows) for label, rows in records.items()}))
output['interpretation'] = 'Latency, process PSS and server CPU/request are separate observations. Median paired ratios may differ from ratios of unpaired label medians. Plaintext pipelining has no meaningful per-request p99; closed-loop HTTP is not a fixed-rate latency experiment.'
filename = 'http-metrics-header-aa.json' if '--header-aa' in sys.argv else ('http-metrics-holdout.json' if '--holdout' in sys.argv else 'http-metrics.json')
(p / filename).write_text(json.dumps(output, indent=2) + '\n')
print('HTTP cases:', {family: len(output[family]) for family in families})
print('Incomplete:', output['incomplete'])
