import hashlib
import json
import os
import resource
import statistics
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
sys.path.insert(0, str(p.parents[1] / 'benchmarks'))
import architecture
import bench
import nginx

assert json.loads((p / 'status.json').read_text()).get('finished_utc')
header_aa = '--header-aa' in sys.argv
plan = json.loads((p / ('nginx-header-aa-plan.json' if header_aa else 'confirmation-plan.json')).read_text())
artifacts = json.loads((p / 'artifacts.json').read_text())
family = sys.argv[1]
assert family in ['architecture', 'nginx']
selection = plan[family]
controls = selection['controls']
soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
if soft < 65536:
    resource.setrlimit(resource.RLIMIT_NOFILE, (65536, hard))
output = p / ('nginx-header-aa' if header_aa else family + '-holdout')
output.mkdir()
for key in list(os.environ):
    if key == 'LD_PRELOAD' or key.startswith(('MIMALLOC_', 'MALLOC_')):
        del os.environ[key]
meta = dict(family=output.name, plan=plan, controls=controls, cases=selection['cases'], status='running', started_utc=bench.utc(), runs=[])

def save():
    (output / 'runs.json').write_text(json.dumps(meta, indent=2) + '\n')

save()
try:
    for i in range(controls['rounds']):
        for case in selection['cases'] if i % 2 == 0 else selection['cases'][::-1]:
            for label in ['old', 'new'] if i % 2 == 0 else ['new', 'old']:
                actual = 'old' if header_aa else label
                library = Path(artifacts['libraries'][actual])
                expected = artifacts['verified'][actual + '.so']['sha256']
                assert hashlib.sha256(library.read_bytes()).hexdigest() == expected
                alias = p / 'active-allocator.so'
                alias.unlink()
                alias.symlink_to(library)
                active = p / 'active-worker'
                active.mkdir()
                env = bench.without_preload()
                if family == 'architecture':
                    key = case['scenario']
                    command = ['taskset', '-c', ','.join(map(str, controls['affinity'])), artifacts['architecture_probe'], '--library', str(alias), '--scenario', key]
                    for flag, name in [('bytes', 'bytes'), ('block-size', 'block_size'), ('threads', 'threads'), ('cycles', 'cycles')]:
                        command += ['--' + flag, str(controls[name])]
                    config = None
                else:
                    key = case['profile'] + '/' + case['case']['label']
                    config = {**controls, **case, 'allocator':'rust', 'artifacts':{k:artifacts['nginx'][k] for k in ['binaries', 'wrk', 'libraries', 'guard']}}
                    (active / 'config.json').write_text(json.dumps({'family':'nginx', **config}, indent=2) + '\n')
                    command = ['taskset', '-c', ','.join(map(str, sorted(os.sched_getaffinity(0)))), sys.executable, str(p / 'worker.py'), str(active / 'config.json'), str(active)]
                destination = output / f'round-{i+1:03}' / key / label
                run = dict(round=i, case=case, label=label, actual_library=str(library), library_sha256=expected,
                           command=command, environment={k:v for k,v in env.items() if k.startswith(('MIMALLOC_', 'MALLOC_')) or k in ['LD_PRELOAD', 'CRITERION_HOME']},
                           configuration=config, directory=str(destination), started_utc=bench.utc())
                meta['runs'].append(run)
                save()
                print(family, i + 1, key, label, 'started', flush=True)
                raw = bench.execute(command, active / 'worker.log', env)
                if family == 'architecture':
                    rows = architecture.validate([json.loads(line) for line in raw.splitlines() if line.startswith('{"phase":')], case['scenario'], controls['cycles'])
                    (active / 'measurements.json').write_text(json.dumps(rows, indent=2) + '\n')
                else:
                    result = nginx.read_result(active / 'nginx.json', config)
                    run['measurement'] = dict(median=1e9/statistics.median(r['requests_per_second'] for r in result['runs']), quality_flags=result['quality_flags'])
                run.update(exit_code=0, finished_utc=bench.utc())
                destination.parent.mkdir(parents=True, exist_ok=True)
                active.rename(destination)
                save()
                print(family, i + 1, key, label, 'finished', flush=True)
    meta.update(status='complete', finished_utc=bench.utc())
    save()
except BaseException as error:
    meta.update(status='failed', error=str(error), finished_utc=bench.utc())
    save()
    raise
