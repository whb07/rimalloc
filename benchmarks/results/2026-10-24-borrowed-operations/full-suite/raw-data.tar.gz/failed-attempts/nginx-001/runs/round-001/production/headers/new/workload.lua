wrk.headers["X-Payload-0"] = string.rep("x", 128)
wrk.headers["X-Payload-1"] = string.rep("x", 512)
wrk.headers["X-Payload-2"] = string.rep("x", 1024)
wrk.headers["X-Payload-3"] = string.rep("x", 4096)
wrk.headers["X-Payload-4"] = string.rep("x", 128)
wrk.headers["X-Payload-5"] = string.rep("x", 512)
wrk.headers["X-Payload-6"] = string.rep("x", 1024)
wrk.headers["X-Payload-7"] = string.rep("x", 4096)
done = function(summary, latency, requests)
  io.write(string.format('BENCH_JSON {"requests":%d,"duration_us":%d,"bytes":%d,"p50_us":%.3f,"p95_us":%.3f,"p99_us":%.3f,"errors":%d}\n',
    summary.requests, summary.duration, summary.bytes, latency:percentile(50), latency:percentile(95), latency:percentile(99),
    summary.errors.connect + summary.errors.read + summary.errors.write + summary.errors.status + summary.errors.timeout))
end
