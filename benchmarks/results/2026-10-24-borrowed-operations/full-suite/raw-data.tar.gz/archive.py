import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
destination = Path(sys.argv[1]).resolve()
status = json.loads((p/'status.json').read_text())
assert status.get('finished_utc')
assert all(s['returncode']==0 for s in status['suites'])
plan = json.loads((p/'measurement-plan.json').read_text())
a = json.loads((p/'artifacts.json').read_text())
for name,item in a['verified'].items():
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],name
source_tree=subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=root,text=True).strip()
expected_tree=subprocess.check_output(['git','rev-parse',plan['candidate_source_commit']+':src'],cwd=root,text=True).strip()
assert source_tree==expected_tree
allocator_builds=json.loads((p/'allocator-builds.json').read_text())
for label,item in allocator_builds.items():
    assert item['data']['commit']==plan['baseline_commit' if label=='old' else 'candidate_source_commit']
    assert item['data']['builds']['interpose']['library_sha256']==a['verified'][label+'.so']['sha256']
results=json.loads((p/'summary.json').read_text())
observations=json.loads((p/'observations.json').read_text())
http_metrics=json.loads((p/'http-metrics.json').read_text())
assert not results['incomplete'] and not observations['incomplete'] and not http_metrics['incomplete']
native_holdout=json.loads((p/'native-holdout-summary.json').read_text())
assert json.loads((p/'native-holdout/runs.json').read_text())['status']=='complete'
confirmation_status=json.loads((p/'confirmations-status.json').read_text())
assert confirmation_status['status']=='complete' and all(s['returncode']==0 for s in confirmation_status['suites'])
architecture_confirmation=json.loads((p/'observations-holdout.json').read_text())
http_confirmation=json.loads((p/'http-metrics-holdout.json').read_text())
assert not architecture_confirmation['incomplete'] and not http_confirmation['incomplete']
retention_confirmation_status=json.loads((p/'retention-followup-status.json').read_text())
assert retention_confirmation_status['status']=='complete' and all(s['returncode']==0 for s in retention_confirmation_status['suites'])
retention_confirmation=json.loads((p/'observations-retention-followup.json').read_text())
assert not retention_confirmation['incomplete']
profile=json.loads((p/'header-profile.json').read_text())
assert profile['status']=='complete' and len(profile['runs'])==2
header_aa=json.loads((p/'http-metrics-header-aa.json').read_text())
assert not header_aa['incomplete'] and len(header_aa['nginx-header-aa'])==1
header_aa_runs=json.loads((p/'nginx-header-aa/runs.json').read_text())
assert header_aa_runs['status']=='complete' and len(header_aa_runs['runs'])==8
assert {r['library_sha256'] for r in header_aa_runs['runs']}=={a['verified']['old.so']['sha256']}
final_checks=json.loads((p/'final-checks.json').read_text())
assert final_checks['status']=='complete' and all(c['returncode']==0 for c in final_checks['checks'])
for check in final_checks['checks']:
    check['log_sha256']=hashlib.sha256((p/check['log']).read_bytes()).hexdigest()
harness_fix=json.loads((p/'nginx-sampler-fix.json').read_text())
assert hashlib.sha256((root/'benchmarks/nginx.py').read_bytes()).hexdigest()==harness_fix['source']['after_sha256']
destination.mkdir(parents=True,exist_ok=True)
assert not (destination/'raw-data.tar.gz').exists()
files=[]
with tarfile.open(destination/'raw-data.tar.gz','w:gz',compresslevel=9) as archive:
    for path in sorted(p.rglob('*')):
        relative=path.relative_to(p)
        if relative.parts[0]=='artifacts' or '__pycache__' in relative.parts or path.is_symlink() or not path.is_file() or (relative.parts[0]=='header-profile' and path.suffix=='.data'):
            continue
        info=archive.gettarinfo(str(path),arcname=str(relative))
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with path.open('rb') as handle:
            archive.addfile(info,handle)
        files.append(str(relative))
    for name in ['bench.py','applications.py','nginx.py','webserver.py','architecture.py','retention.py','common.py']:
        path=root/'benchmarks'/name
        info=archive.gettarinfo(str(path),arcname='benchmark-source/'+name)
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with path.open('rb') as handle:
            archive.addfile(info,handle)
        files.append('benchmark-source/'+name)
manifest=dict(plan=plan,status=status,artifacts=a,allocator_builds=allocator_builds,source_tree=source_tree,initial_source_confirmation=json.loads((p/'artifact-source-confirmation.json').read_text()),benchmark_harness_correction=harness_fix,confirmations=dict(plan=json.loads((p/'confirmation-plan.json').read_text()),status=confirmation_status),final_checks=final_checks,raw_archive=dict(path='raw-data.tar.gz',sha256=hashlib.sha256((destination/'raw-data.tar.gz').read_bytes()).hexdigest(),files=len(files),scope='Complete frozen-run controller sources, plans, configuration, per-worker raw samples, logs and protocol results, including the failed Nginx attempt. Large application executables, allocator libraries and raw perf recordings are represented by verified fingerprints and build provenance.'))
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
results['observations']=observations
results['http_metrics']=http_metrics
results['native_holdout']=native_holdout
results['architecture_confirmation']=architecture_confirmation
results['http_confirmation']=http_confirmation
results['retention_confirmation']=dict(plan=json.loads((p/'retention-confirmation-plan.json').read_text()),status=retention_confirmation_status,summary=retention_confirmation['retention'])
results['diagnostic_header_profile']=profile
results['same_baseline_header_control']=dict(plan=json.loads((p/'nginx-header-aa-plan.json').read_text()),measurements=header_aa)
(destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print('Archived',len(files),'raw files',flush=True)
