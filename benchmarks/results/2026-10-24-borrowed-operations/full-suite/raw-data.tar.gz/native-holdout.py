import hashlib
import json
import os
import resource
import statistics
import sys
from pathlib import Path
from types import SimpleNamespace

p = Path(__file__).resolve().parent
sys.path.insert(0, str(p.parents[1] / 'benchmarks'))
import bench

assert json.loads((p / 'status.json').read_text()).get('finished_utc')
plan = json.loads((p / 'native-holdout-plan.json').read_text())
artifacts = json.loads((p / 'artifacts.json').read_text())
soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
if soft < 65536:
    resource.setrlimit(resource.RLIMIT_NOFILE, (65536, hard))
for key in list(os.environ):
    if key == 'LD_PRELOAD' or key.startswith(('MIMALLOC_', 'MALLOC_')):
        del os.environ[key]
output = p / 'native-holdout'
output.mkdir()
meta = dict(plan=plan, status='running', started_utc=bench.utc(), runs=[])

def save():
    (output / 'runs.json').write_text(json.dumps(meta, indent=2) + '\n')

save()
try:
    for i in range(plan['rounds']):
        for case in plan['cases'] if i % 2 == 0 else plan['cases'][::-1]:
            for label in ['old', 'new'] if i % 2 == 0 else ['new', 'old']:
                library = Path(artifacts['libraries'][label])
                expected = artifacts['verified'][label + '.so']['sha256']
                assert hashlib.sha256(library.read_bytes()).hexdigest() == expected
                alias = p / 'active-allocator.so'
                alias.unlink()
                alias.symlink_to(library)
                active = p / 'active-worker'
                active.mkdir()
                controls = case['controls']
                core = {**artifacts['core'], 'rust_library': str(alias)}
                env = bench.worker_environment(core, SimpleNamespace(samples=10, measurement_secs=3, warmup_secs=1), active / 'criterion', case['scenario'], bench.ALLOCATORS[0])
                env['MIMALLOC_BENCH_QUICK_RUNS'] = str(controls['raw_runs'])
                if controls.get('timed_secs') is not None:
                    env['MIMALLOC_BENCH_TIMED_SECS'] = str(controls['timed_secs'])
                command = ['taskset', '-c', ','.join(map(str, plan['affinity'])), core['executable'], '--bench', 'mimalloc-bench-native', '--noplot']
                destination = output / f'round-{i+1:03}' / case['scenario'] / label
                run = dict(round=i, scenario=case['scenario'], label=label, actual_library=str(library), library_sha256=expected,
                           command=command, environment={k:v for k,v in env.items() if k.startswith(('MIMALLOC_', 'MALLOC_')) or k in ['LD_PRELOAD', 'CRITERION_HOME']},
                           directory=str(destination), started_utc=bench.utc())
                meta['runs'].append(run)
                save()
                print(i + 1, case['scenario'], label, 'started', flush=True)
                raw = bench.execute(command, active / 'worker.log', env)
                samples = [json.loads(line.removeprefix('QUICK ')) for line in raw.splitlines() if line.startswith('QUICK ')]
                assert len(samples) == controls['raw_runs']
                assert all(s['allocator'] == bench.ALLOCATORS[0] and s['scenario'] == case['scenario'] and s['ns'] > 0 for s in samples)
                run.update(samples=samples, median=statistics.median(s['ns'] for s in samples[controls['discard_warmup']:]), exit_code=0, finished_utc=bench.utc())
                destination.parent.mkdir(parents=True, exist_ok=True)
                active.rename(destination)
                save()
                print(i + 1, case['scenario'], label, 'finished', flush=True)
    rows = []
    for case in plan['cases']:
        ratios = []
        for i in range(plan['rounds']):
            pair = {r['label']:r for r in meta['runs'] if r['round'] == i and r['scenario'] == case['scenario']}
            for key in ['command', 'environment']:
                assert pair['old'][key] == pair['new'][key]
            ratios.append(pair['new']['median'] / pair['old']['median'])
        rows.append(dict(scenario=case['scenario'], paired_ratios=ratios, median_ratio=statistics.median(ratios)))
    meta.update(status='complete', finished_utc=bench.utc(), summary=rows)
    save()
except BaseException as error:
    meta.update(status='failed', error=str(error), finished_utc=bench.utc())
    save()
    raise
